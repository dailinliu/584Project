
#define BOOST_TEST_MODULE Voldemort C++ Client Test Suite
#include <boost/test/unit_test.hpp>
