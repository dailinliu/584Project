class SerializationException(Exception):
    pass

