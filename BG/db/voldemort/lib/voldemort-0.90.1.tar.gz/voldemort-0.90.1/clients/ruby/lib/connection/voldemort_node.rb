class VoldemortNode
  attr_accessor :id, :host, :port, :http_port, :admin_port, :partitions
end