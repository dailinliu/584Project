require 'rubygems'
require 'voldemort-rb'